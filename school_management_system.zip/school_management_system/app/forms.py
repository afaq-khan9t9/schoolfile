from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SelectField, DateField, BooleanField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Length, Email, EqualTo

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=150)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    role = SelectField('Role', choices=[('admin', 'Admin'), ('teacher', 'Teacher'), ('student', 'Student'), ('parent', 'Parent')], validators=[DataRequired()])
    submit = SubmitField('Register')

class EnrollmentForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired(), Length(max=100)])
    age = IntegerField('Age', validators=[DataRequired()])
    grade = StringField('Grade', validators=[DataRequired(), Length(max=20)])
    contact_info = StringField('Contact Info', validators=[DataRequired(), Length(max=200)])
    submit = SubmitField('Enroll Student')

class TeacherForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired(), Length(max=100)])
    subject = StringField('Subject', validators=[DataRequired(), Length(max=100)])
    contact_info = StringField('Contact Info', validators=[DataRequired(), Length(max=200)])
    submit = SubmitField('Add Teacher')

class ClassForm(FlaskForm):
    name = StringField('Class Name', validators=[DataRequired(), Length(max=100)])
    grade = StringField('Grade', validators=[DataRequired(), Length(max=20)])
    teacher_id = SelectField('Teacher', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Create Class')

class AttendanceForm(FlaskForm):
    student_id = SelectField('Student', coerce=int, validators=[DataRequired()])
    class_id = SelectField('Class', coerce=int, validators=[DataRequired()])
    date = DateField('Date', validators=[DataRequired()])
    status = SelectField('Status', choices=[('present', 'Present'), ('absent', 'Absent')], validators=[DataRequired()])
    submit = SubmitField('Mark Attendance')

class GradeForm(FlaskForm):
    student_id = SelectField('Student', coerce=int, validators=[DataRequired()])
    subject = StringField('Subject', validators=[DataRequired(), Length(max=100)])
    grade = StringField('Grade', validators=[DataRequired(), Length(max=5)])
    date = DateField('Date', validators=[DataRequired()])
    submit = SubmitField('Add Grade')

class FeeForm(FlaskForm):
    student_id = SelectField('Student', coerce=int, validators=[DataRequired()])
    amount = IntegerField('Amount', validators=[DataRequired()])
    description = StringField('Description', validators=[DataRequired(), Length(max=200)])
    due_date = DateField('Due Date', validators=[DataRequired()])
    paid = BooleanField('Paid')
    submit = SubmitField('Add Fee')

class BookForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired(), Length(max=200)])
    author = StringField('Author', validators=[DataRequired(), Length(max=100)])
    isbn = StringField('ISBN', validators=[DataRequired(), Length(max=20)])
    submit = SubmitField('Add Book')

class LoanForm(FlaskForm):
    student_id = SelectField('Student', coerce=int, validators=[DataRequired()])
    book_id = SelectField('Book', coerce=int, validators=[DataRequired()])
    loan_date = DateField('Loan Date', validators=[DataRequired()])
    return_date = DateField('Return Date')
    submit = SubmitField('Loan Book')
