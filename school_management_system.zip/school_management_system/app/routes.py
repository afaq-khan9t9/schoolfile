from . import app, db
from .models import Student
from .forms import EnrollmentForm

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/enroll', methods=['GET', 'POST'])
def enroll():
    form = EnrollmentForm()
    if form.validate_on_submit():
        student = Student(
            name=form.name.data,
            age=form.age.data,
            grade=form.grade.data,
            contact_info=form.contact_info.data
        )
        db.session.add(student)
        db.session.commit()
        flash('Student enrolled successfully!')
        return redirect(url_for('index'))
    return render_template('enroll.html', form=form)
=======
from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from . import app, db, login_manager
from .models import User, Student, Teacher, Class, Attendance, Grade, Fee, Book, Loan
from .forms import LoginForm, RegistrationForm, EnrollmentForm, TeacherForm, ClassForm, AttendanceForm, GradeForm, FeeForm, BookForm, LoanForm

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data, method='sha256')
        new_user = User(username=form.username.data, password=hashed_password, role=form.role.data)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful!')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    if current_user.role == 'admin':
        students = Student.query.all()
        teachers = Teacher.query.all()
        classes = Class.query.all()
        return render_template('admin_dashboard.html', students=students, teachers=teachers, classes=classes)
    elif current_user.role == 'teacher':
        classes = Class.query.filter_by(teacher_id=current_user.id).all()
        return render_template('teacher_dashboard.html', classes=classes)
    elif current_user.role == 'student':
        student = Student.query.filter_by(user_id=current_user.id).first()
        grades = Grade.query.filter_by(student_id=student.id).all() if student else []
        attendance = Attendance.query.filter_by(student_id=student.id).all() if student else []
        fees = Fee.query.filter_by(student_id=student.id).all() if student else []
        return render_template('student_dashboard.html', student=student, grades=grades, attendance=attendance, fees=fees)
    return render_template('dashboard.html')

@app.route('/enroll', methods=['GET', 'POST'])
@login_required
def enroll():
    if current_user.role not in ['admin', 'teacher']:
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = EnrollmentForm()
    if form.validate_on_submit():
        student = Student(
            name=form.name.data,
            age=form.age.data,
            grade=form.grade.data,
            contact_info=form.contact_info.data
        )
        db.session.add(student)
        db.session.commit()
        flash('Student enrolled successfully!')
        return redirect(url_for('dashboard'))
    return render_template('enroll.html', form=form)

@app.route('/add_teacher', methods=['GET', 'POST'])
@login_required
def add_teacher():
    if current_user.role != 'admin':
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = TeacherForm()
    if form.validate_on_submit():
        teacher = Teacher(
            name=form.name.data,
            subject=form.subject.data,
            contact_info=form.contact_info.data
        )
        db.session.add(teacher)
        db.session.commit()
        flash('Teacher added successfully!')
        return redirect(url_for('dashboard'))
    return render_template('add_teacher.html', form=form)

@app.route('/create_class', methods=['GET', 'POST'])
@login_required
def create_class():
    if current_user.role != 'admin':
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = ClassForm()
    form.teacher_id.choices = [(t.id, t.name) for t in Teacher.query.all()]
    if form.validate_on_submit():
        new_class = Class(
            name=form.name.data,
            grade=form.grade.data,
            teacher_id=form.teacher_id.data
        )
        db.session.add(new_class)
        db.session.commit()
        flash('Class created successfully!')
        return redirect(url_for('dashboard'))
    return render_template('create_class.html', form=form)

@app.route('/mark_attendance', methods=['GET', 'POST'])
@login_required
def mark_attendance():
    if current_user.role not in ['admin', 'teacher']:
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = AttendanceForm()
    form.student_id.choices = [(s.id, s.name) for s in Student.query.all()]
    form.class_id.choices = [(c.id, c.name) for c in Class.query.all()]
    if form.validate_on_submit():
        attendance = Attendance(
            student_id=form.student_id.data,
            class_id=form.class_id.data,
            date=form.date.data,
            status=form.status.data
        )
        db.session.add(attendance)
        db.session.commit()
        flash('Attendance marked successfully!')
        return redirect(url_for('dashboard'))
    return render_template('mark_attendance.html', form=form)

@app.route('/add_grade', methods=['GET', 'POST'])
@login_required
def add_grade():
    if current_user.role not in ['admin', 'teacher']:
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = GradeForm()
    form.student_id.choices = [(s.id, s.name) for s in Student.query.all()]
    if form.validate_on_submit():
        grade = Grade(
            student_id=form.student_id.data,
            subject=form.subject.data,
            grade=form.grade.data,
            date=form.date.data
        )
        db.session.add(grade)
        db.session.commit()
        flash('Grade added successfully!')
        return redirect(url_for('dashboard'))
    return render_template('add_grade.html', form=form)

@app.route('/add_fee', methods=['GET', 'POST'])
@login_required
def add_fee():
    if current_user.role != 'admin':
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = FeeForm()
    form.student_id.choices = [(s.id, s.name) for s in Student.query.all()]
    if form.validate_on_submit():
        fee = Fee(
            student_id=form.student_id.data,
            amount=form.amount.data,
            description=form.description.data,
            due_date=form.due_date.data,
            paid=form.paid.data
        )
        db.session.add(fee)
        db.session.commit()
        flash('Fee added successfully!')
        return redirect(url_for('dashboard'))
    return render_template('add_fee.html', form=form)

@app.route('/add_book', methods=['GET', 'POST'])
@login_required
def add_book():
    if current_user.role != 'admin':
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = BookForm()
    if form.validate_on_submit():
        book = Book(
            title=form.title.data,
            author=form.author.data,
            isbn=form.isbn.data
        )
        db.session.add(book)
        db.session.commit()
        flash('Book added successfully!')
        return redirect(url_for('dashboard'))
    return render_template('add_book.html', form=form)

@app.route('/loan_book', methods=['GET', 'POST'])
@login_required
def loan_book():
    if current_user.role not in ['admin', 'teacher']:
        flash('Access denied')
        return redirect(url_for('dashboard'))
    form = LoanForm()
    form.student_id.choices = [(s.id, s.name) for s in Student.query.all()]
    form.book_id.choices = [(b.id, b.title) for b in Book.query.filter_by(available=True).all()]
    if form.validate_on_submit():
        loan = Loan(
            student_id=form.student_id.data,
            book_id=form.book_id.data,
            loan_date=form.loan_date.data,
            return_date=form.return_date.data
        )
        book = Book.query.get(form.book_id.data)
        book.available = False
        db.session.add(loan)
        db.session.commit()
        flash('Book loaned successfully!')
        return redirect(url_for('dashboard'))
    return render_template('loan_book.html', form=form)

@app.route('/reports')
@login_required
def reports():
    if current_user.role != 'admin':
        flash('Access denied')
        return redirect(url_for('dashboard'))
    students = Student.query.all()
    teachers = Teacher.query.all()
    classes = Class.query.all()
    attendance = Attendance.query.all()
    grades = Grade.query.all()
    fees = Fee.query.all()
    books = Book.query.all()
    loans = Loan.query.all()
    return render_template('reports.html', students=students, teachers=teachers, classes=classes, attendance=attendance, grades=grades, fees=fees, books=books, loans=loans)
