#!/usr/bin/env python3
"""
School Management System Launcher
This script sets up and runs the school management system.
"""

import os
import sys
import subprocess

def run_command(command, description):
    """Run a command and return success status."""
    print(f"\n{description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print("✓ Success!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed: {e}")
        print(f"Error output: {e.stderr}")
        return False

def main():
    print("🎓 School Management System Setup & Launcher")
    print("=" * 50)

    # Check if we're in the right directory
    if not os.path.exists('app'):
        print("❌ Error: Please run this script from the school_management_system directory")
        sys.exit(1)

    # Install dependencies
    if not run_command("pip install -r requirements.txt", "Installing Python dependencies"):
        sys.exit(1)

    # Initialize database
    if not run_command("python init_db.py", "Initializing database"):
        sys.exit(1)

    print("\n✅ Setup complete! Starting the application...")
    print("🌐 Open your browser to: http://localhost:5000")
    print("📝 First, register as an admin user")
    print("Press Ctrl+C to stop the server\n")

    # Run the application
    try:
        subprocess.run([sys.executable, "run.py"], check=True)
    except KeyboardInterrupt:
        print("\n👋 Server stopped. Goodbye!")
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Error running application: {e}")

if __name__ == "__main__":
    main()
