#!/usr/bin/env python3
"""
Build standalone executable for School Management System
"""

import os
import sys
import subprocess
import shutil

def run_command(command, description):
    """Run a command and return success status."""
    print(f"\n{description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print("✓ Success!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed: {e}")
        print(f"Error output: {e.stderr}")
        return False

def main():
    print("🔨 Building School Management System Executable")
    print("=" * 50)

    # Check if PyInstaller is installed
    try:
        import PyInstaller
        print("✓ PyInstaller is available")
    except ImportError:
        print("Installing PyInstaller...")
        if not run_command("pip install pyinstaller", "Installing PyInstaller"):
            sys.exit(1)

    # Create the executable
    print("\n📦 Creating executable...")

    # PyInstaller command for Flask app
    cmd = [
        "pyinstaller",
        "--onefile",  # Single executable file
        "--windowed",  # No console window (for GUI apps, but we'll keep console for Flask)
        "--name=SchoolManagementSystem",
        "--add-data=templates;templates",
        "--add-data=static;static",
        "run.py"
    ]

    if not run_command(" ".join(cmd), "Building executable with PyInstaller"):
        sys.exit(1)

    # Copy additional files
    print("\n📋 Copying additional files...")
    dist_dir = "dist"

    # Copy README and requirements for reference
    if os.path.exists("README.md"):
        shutil.copy("README.md", os.path.join(dist_dir, "README.md"))

    # Create a simple batch file to run the exe
    batch_content = '''@echo off
echo Starting School Management System...
echo.
echo If the application doesn't start, make sure no other programs are using port 5000
echo.
echo Press Ctrl+C to stop the server
echo.
SchoolManagementSystem.exe
pause
'''

    with open(os.path.join(dist_dir, "Run_School_System.bat"), "w") as f:
        f.write(batch_content)

    # Create a setup instruction file
    setup_content = '''SCHOOL MANAGEMENT SYSTEM - SETUP INSTRUCTIONS
===============================================

1. FIRST TIME SETUP:
   - Double-click "Run_School_System.bat" to start the application
   - The database will be created automatically on first run

2. ACCESS THE SYSTEM:
   - Open your web browser
   - Go to: http://localhost:5000
   - Register your first admin account

3. INITIAL CONFIGURATION:
   - Set up fee structures for different grades
   - Add teachers
   - Create classes
   - Start enrolling students

4. DAILY USE:
   - Mark attendance
   - Enter grades
   - Manage fees
   - Generate reports

IMPORTANT NOTES:
- Keep all files in this folder together
- The system creates a database file (school_management.db) to store your data
- Your data will persist between sessions
- Make sure port 5000 is not blocked by firewall/antivirus

TROUBLESHOOTING:
- If the application doesn't start, try running as Administrator
- If port 5000 is in use, close other web applications
- Check Windows Firewall settings

For support or questions, refer to README.md
'''

    with open(os.path.join(dist_dir, "SETUP_INSTRUCTIONS.txt"), "w") as f:
        f.write(setup_content)

    print("\n✅ Executable created successfully!")
    print(f"📁 Files are in the '{dist_dir}' folder:")
    print("   - SchoolManagementSystem.exe (main application)")
    print("   - Run_School_System.bat (easy launcher)")
    print("   - SETUP_INSTRUCTIONS.txt (how to use)")
    print("   - README.md (detailed documentation)")

    print("\n🚀 To run the application:")
    print("   1. Go to the 'dist' folder")
    print("   2. Double-click 'Run_School_System.bat'")
    print("   3. Open http://localhost:5000 in your browser")

if __name__ == "__main__":
    main()
