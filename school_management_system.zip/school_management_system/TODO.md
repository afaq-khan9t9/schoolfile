# School Management System Development TODO

## Phase 1: Project Setup and Enrollment Module
- [x] Create project directory structure (app/, templates/, static/, database/)
- [x] Create requirements.txt with dependencies (Flask, SQLAlchemy, Flask-WTF, Bootstrap)
- [x] Create run.py to run the Flask app
- [x] Create app/__init__.py for Flask app initialization
- [x] Create app/models.py for database models (Student model for enrollment)
- [x] Create app/forms.py for enrollment form (WTForms)
- [x] Create app/routes.py for enrollment routes
- [x] Create templates/base.html (base template with Bootstrap)
- [x] Create templates/index.html (home page)
- [x] Create templates/enroll.html (enrollment form template)
- [x] Create static/styles.css (custom styles)
- [x] Create init_db.py for database initialization
- [ ] Install Python dependencies (requires Python installation)
- [ ] Initialize database and run app locally to test enrollment

## Phase 2: User Authentication and Roles
- [x] Add User model and authentication (Flask-Login)
- [x] Implement login/logout routes and templates
- [x] Add role-based access (admin, teacher, student, parent)

## Phase 3: Teacher Management
- [x] Create Teacher model
- [x] Add teacher registration/enrollment routes and forms
- [x] Teacher dashboard

## Phase 4: Class Scheduling
- [x] Create Class and Schedule models
- [x] Add class creation and assignment routes
- [x] Timetable views

## Phase 5: Attendance Tracking
- [x] Create Attendance model
- [x] Add attendance marking routes and forms
- [x] Attendance reports

## Phase 6: Grading System
- [x] Create Grade and Subject models
- [x] Add grade entry and viewing routes
- [x] Report cards

## Phase 7: Fee Management
- [x] Create Fee model
- [x] Add fee structure and payment tracking
- [x] Invoices and receipts

## Phase 8: Library System
- [x] Create Book and Loan models
- [x] Add book catalog and borrowing/returning routes

## Phase 9: Reports and Dashboards
- [x] Add reporting routes (student lists, attendance summaries, etc.)
- [x] Admin and teacher dashboards

## Phase 10: Testing and Deployment
- [ ] Test all features
- [ ] Add error handling and validation
- [ ] Deploy locally or prepare for production
- [ ] Package as standalone executable using PyInstaller
